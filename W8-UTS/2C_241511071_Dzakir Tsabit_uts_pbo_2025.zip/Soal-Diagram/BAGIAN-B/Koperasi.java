public class Koperasi {
    private int loanMonthly;

    public Koperasi(int loanMonthly) {
        this.loanMonthly = loanMonthly;
    }

    public int getLoanMonthly() {
        return loanMonthly;
    }
}