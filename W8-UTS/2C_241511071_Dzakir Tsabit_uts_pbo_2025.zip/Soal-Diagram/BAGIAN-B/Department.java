public class Department {

    private String departemenName;

    public Department(String name) {
        this.departemenName = name;
    }

    public String getDepartemenName() {
        return departemenName;
    }
}
