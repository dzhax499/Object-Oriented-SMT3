interface Koperasi {
    void loanMonthly();
}
